# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,seperated


matilda:$1$wzpI4IUu$AU8ozTDYLxezCkW3ohUEZ.:Matilda:matildak1992@gmail.com:admin,user
chris:$1$mJci9poz$HIjv5m7o8Gv3zlKtWifUx1:Chris:christian.bang@gmail.com:user,admin
pvt:$1$GsBhFqqh$2I56n2X93jpFQ2E.ryh/b1:Pvt:pvt@cs.umu.se:admin,user
sojk:$1$1x329YfP$1wDl3Uby6xZE1ECyoGiHO0:Oskar Suikki:oskar.suikki@gmail.com:user
c13afd:$1$NEt3E1fr$tlUMhgDbarZdMFcO2FYMO/:Aria:c13afd@cs.umu.se:user
c13ljn:$1$PubOcBPK$62QMz6YtWsrKVFPZKBzAP0:Leonard Jakobsson:leo.jacobsson@outlook.com:user
